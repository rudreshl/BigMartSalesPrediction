import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
import sklearn.linear_model
import sklearn.ensemble
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import pickle
data = pd.read_csv("data.csv")

data.dtypes

# label encoding

from sklearn.preprocessing import LabelEncoder

data.apply(LabelEncoder().fit_transform)

#one hot encoding

data = pd.get_dummies(data)
data.head()
# splitting the data into dependent and independent variables
x = data.drop('Item_Outlet_Sales', axis = 1)
y = data.Item_Outlet_Sales
x.to_csv(r'output.csv')
print(x.shape)
print(y.shape)

train = data.iloc[:8523,:]
test = data.iloc[8523:,:]

print(train.shape)
print(test.shape)

from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.3)

print(x_train.shape)
print(y_train.shape)
print(x_test.shape)
print(y_test.shape)



from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score

model = LinearRegression()
model.fit(x_train, y_train)
pickle.dump(model, open('model.pkl','wb'))
# predicting the  test set results

model1 = pickle.load(open('model.pkl','rb'))
print('success')
print(model1.predict([[249.8092,0.016047301,9.3,1999,19,1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1,0,0,1,0,0]]))
print('success')
y_pred = model1.predict(x_test)
print(y_pred)

# finding the mean squared error and variance
mse = mean_squared_error(y_test, y_pred)
print('RMSE :', np.sqrt(mse))
print('Variance score: %.2f' % r2_score(y_test, y_pred))
