import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle

app = Flask(__name__)
model = pickle.load(open('model.pkl', 'rb'))
final_features1=[[249.8092,0.016047301,9.3,1999,19,1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1,0,0,1,0,0]]
@app.route("/")
def home():
    return render_template('home.html')


@app.route("/predict")
def p():
    return render_template('predict.html')

@app.route('/predict1',methods=['POST'])
def predict():
    item_mrpi=request.form['item_mrp']
    item_vi=request.form['item_v']
    item_wi=request.form['item_w']
    esti_yeari=request.form['esti_year']
    out_yeari=request.form['out_year']
    item_mrp=float(item_mrpi)
    item_v=float(item_vi)
    item_w=float(item_wi)
    esti_year=int(esti_yeari)
    out_year=int(out_yeari)
    numbers=[item_mrp,item_v,item_w,esti_year,out_year]
    fat=request.form['fat']
    iid=request.form['iid']
    it=request.form['it']
    outlet=request.form['outlet']
    out_loc=request.form['out_loc']
    out_size=request.form['out_size']
    out_type=request.form['out_type']
    
    fats = [int(x) for x in str(fat)]
    its= [int(x) for x in str(it)]
    iidl = [int(x) for x in str(iid)]
    outletl= [int(x) for x in str(outlet)]
    out_locl= [int(x) for x in str(out_loc)]
    out_sizel = [int(x) for x in str(out_size)]
    out_typel= [int(x) for x in str(out_type)]
    list1=numbers+fats+iidl+its+outletl+out_locl+out_sizel+out_typel        
    list2=[list1]
    prediction = model.predict(list2)

    #output = round(prediction[0], 2)

    return render_template('predict.html', prediction_text='Item Sales should be  {} '.format(prediction))

@app.route("/about")
def about():
    return render_template('about.html')

@app.route("/research")
def research():
    return render_template('research.html')

@app.route('/predict_api',methods=['POST'])
def predict_api():
    '''
    For direct API calls trought request
    '''
    data = request.get_json(force=True)
    prediction = model.predict([np.array(list(data.values()))])

    output = prediction[0]
    return jsonify(output)

if __name__ == "__main__":
    app.run(debug=True)
