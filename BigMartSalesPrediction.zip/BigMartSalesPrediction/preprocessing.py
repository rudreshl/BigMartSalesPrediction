import pandas as pd 
import numpy as np
train = pd.read_csv("Train.csv")
test = pd.read_csv("Test.csv")
data = pd.concat([train, test])
data_Missing=data.isnull().sum()
twowaytable=pd.crosstab(data['Outlet_Size'],data['Outlet_Type'])
d={'Grocery Store':'Small'}
s=data.Outlet_Type.map(d)
data.Outlet_Size=data.Outlet_Size.combine_first(s)
twowaytable=pd.crosstab(data['Outlet_Size'],data['Outlet_Location_Type'])
d={'Tier 2':'Small'}
s=data.Outlet_Location_Type.map(d)
data.Outlet_Size=data.Outlet_Size.combine_first(s)

data_Missing=data.isnull().sum()
data['Item_Weight'] = data['Item_Weight'].replace(0, np.NaN)
data['Item_Weight']=data['Item_Weight'].fillna(data.groupby('Item_Identifier')['Item_Weight'].transform('mean'))
data['Item_Weight'].fillna(data['Item_Weight'].mean(), inplace = True)

data_Missing=data.isnull().sum()


data['Item_Outlet_Sales'] = data['Item_Outlet_Sales'].replace(0, np.NaN)
data['Item_Outlet_Sales'].fillna(data['Item_Outlet_Sales'].mode()[0], inplace = True)

data.Item_Visibility.value_counts()

data_Missing=data.isnull().sum()


#data['Item_Visibility'].replace('0.0000',np.nan)#first fill by nam for simplicity
data['Item_Visibility'].replace(0.000000, np.nan, inplace=True)
data['Item_Visibility']=data['Item_Visibility'].replace(np.nan,(data.groupby('Item_Identifier')['Item_Visibility'].transform('mean')))
#df['DataFrame Column'] = df['DataFrame Column'].replace(np.nan, 0)

data_Missing=data.isnull().sum()


data.Item_Visibility.value_counts()

data['Item_Fat_Content'] = data['Item_Fat_Content'].replace({'LF': 'Low Fat', 'reg': 'Regular', 'low fat': 'Low Fat'})
data['Item_Fat_Content'].value_counts()

data['Item_Identifier'] = data['Item_Identifier'].apply(lambda x: x[0:2])

data['Item_Identifier'] = data['Item_Identifier'].map({'FD':'Food', 'NC':'Non_Consumable', 'DR':'Drinks'})

data.loc[data['Item_Identifier']=='Non_Consumable','Item_Fat_Content']='Non-Edible'

data['Item_Identifier'].value_counts()

data['Outlet_Years']=2018-data['Outlet_Establishment_Year']
data['Outlet_Years'].value_counts()
data.to_csv(r'data.csv')

